import * as React from 'react';
import { useState, useRef } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ResultsSection from './components/ResultsSection';
import PricingSection from './components/PricingSection';
import { Candidate, RankedCandidate, AppState } from './types';
import { uploadResumes, getScores, generateReport, getTotalResumes } from './services/api';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [resumes, setResumes] = useState<Candidate[]>([]);
  const [totalResumesCount, setTotalResumesCount] = useState<number>(0);

  // JD State
  const [jdInputType, setJdInputType] = useState<'text' | 'file'>('text');
  const [jobDescription, setJobDescription] = useState<string>('');
  const [jdFile, setJdFile] = useState<File | null>(null);

  const [rankedCandidates, setRankedCandidates] = useState<RankedCandidate[]>([]);
  const [reportContent, setReportContent] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  const resumeInputRef = useRef<HTMLInputElement>(null);
  const jdInputRef = useRef<HTMLTextAreaElement>(null);
  const jdFileInputRef = useRef<HTMLInputElement>(null);

  const handleResumeUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const files: File[] = Array.from(event.target.files);

      try {
        // Upload to backend
        await uploadResumes(files);

        // Update local state for UI feedback
        const newResumes: Candidate[] = [];
        for (const file of files) {
          newResumes.push({
            id: Math.random().toString(36).substr(2, 9),
            name: file.name,
            content: "Uploaded to backend"
          });
        }
        setResumes(prev => [...prev, ...newResumes]);
        setTotalResumesCount(prev => prev + files.length);

        if (appState === AppState.IDLE) {
          setAppState(AppState.RESUMES_UPLOADED);
        }
      } catch (e: any) {
        console.error("Failed to upload resumes", e);
        setErrorMsg("Failed to upload resumes: " + e.message);
      }
    }
  };

  const handleUseExistingResumes = async () => {
    try {
      const total = await getTotalResumes();
      if (total > 0) {
        // Populate resumes with a placeholder to enable the next step
        setResumes([{ id: 'existing', name: `${total} Existing Resumes`, content: 'Existing database content' }]);
        setTotalResumesCount(total);
        setAppState(AppState.RESUMES_UPLOADED);
      } else {
        alert("No existing resumes found in the database. Please upload new ones.");
      }
    } catch (error) {
      console.error("Failed to check existing resumes", error);
      alert("Failed to check existing resumes.");
    }
  };

  const handleJdFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setJdFile(event.target.files[0]);
      setAppState(AppState.READY_TO_RANK);
    }
  };

  const handleRank = async () => {
    if (resumes.length === 0) {
      setErrorMsg("Please upload resumes first.");
      return;
    }

    // Validation based on input type
    if (jdInputType === 'text' && !jobDescription) return;
    if (jdInputType === 'file' && !jdFile) return;

    setAppState(AppState.ANALYZING);
    setErrorMsg('');

    try {
      // 1. Get Scores
      const scoresData = await getScores(jdFile, jdInputType === 'text' ? jobDescription : null);

      // Transform scores data to RankedCandidate format
      // Backend returns: { "resume_id": { "overall_score": 85, ... }, ... }
      // We need to map this to our frontend type. 
      // Note: The backend response keys are resume IDs. We might need to fetch resume details if we want names.
      // However, the scores endpoint returns a dict where keys are IDs and values are score objects.
      // The score object contains "person_name" and "file_path".

      const candidates: RankedCandidate[] = Object.entries(scoresData).map(([id, data]: [string, any]) => ({
        id: id,
        name: data.person_name !== "Unknown" ? data.person_name : data.file_path.split('/').pop() || "Unknown Candidate",
        score: Math.round(data.overall_score), // Assuming score is 0-100
        summary: `Experience Score: ${data.experience_score}, Skills Score: ${data.keyword_skills_score}`, // Placeholder summary
        pros: [], // Backend doesn't return pros/cons list in scores, only in LLM report
        cons: [],
        fileName: data.file_path.split('/').pop() || ""
      })).sort((a, b) => b.score - a.score);

      setRankedCandidates(candidates);

      // 2. Generate Report
      const reportData = await generateReport(jdFile, jdInputType === 'text' ? jobDescription : null);
      setReportContent(reportData.results);

      setAppState(AppState.RESULTS);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An unexpected error occurred during analysis.");
      setAppState(AppState.ERROR);
    }
  };

  const resetApp = () => {
    setResumes([]);
    setJobDescription('');
    setJdFile(null);
    setRankedCandidates([]);
    setReportContent('');
    setAppState(AppState.IDLE);
    setJdInputType('text');
    if (jdInputRef.current) jdInputRef.current.value = '';
    if (resumeInputRef.current) resumeInputRef.current.value = '';
    if (jdFileInputRef.current) jdFileInputRef.current.value = '';
  };

  // --- Render Helpers ---

  const renderHero = () => (
    <section className="py-16 sm:py-20 animate-fade-in">
      <div className="@container">
        <div className="flex flex-col gap-10 px-4">
          <div className="flex flex-col gap-4 text-center items-center">
            <h1 className="text-gray-900 dark:text-white text-4xl font-black leading-tight tracking-[-0.033em] @[480px]:text-5xl max-w-2xl">
              Hire Smarter, Not Harder. Find Your Perfect Candidate in Minutes.
            </h1>
            <h2 className="text-gray-600 dark:text-text-secondary-dark text-base font-normal leading-normal @[480px]:text-lg max-w-2xl">
              Start by providing resumes, then upload a job description to instantly rank candidates with the power of AI.
            </h2>
          </div>

          <div className="flex justify-center">
            <div className="w-full max-w-3xl flex flex-col items-center gap-8">

              {/* Step 1: Upload Resumes */}
              <div className="w-full grid grid-cols-1 @[480px]:grid-cols-2 gap-6 items-stretch">
                <button
                  onClick={() => resumeInputRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-4 p-8 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-primary dark:hover:border-primary hover:bg-blue-50 dark:hover:bg-primary/10 transition-all group"
                >
                  <input
                    type="file"
                    multiple
                    ref={resumeInputRef}
                    className="hidden"
                    accept=".pdf,.docx,.doc"
                    onChange={handleResumeUpload}
                  />
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined text-primary text-3xl">upload_file</span>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-gray-900 dark:text-white">
                      {resumes.length > 0 ? `${resumes.length} Resumes Added` : "Upload Resumes"}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {resumes.length > 0 ? "Click to add more" : "Drag & drop or click to select files (PDF, DOCX)"}
                    </p>
                  </div>
                </button>

                <button
                  onClick={handleUseExistingResumes}
                  className="flex flex-col items-center justify-center gap-4 p-8 rounded-xl border border-gray-200 dark:border-border-dark bg-white dark:bg-surface-dark hover:border-primary dark:hover:border-primary hover:bg-blue-50 dark:hover:bg-primary/10 transition-all group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined text-primary text-3xl">storage</span>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-gray-900 dark:text-white">Use Existing Database</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Skip upload</p>
                  </div>
                </button>
              </div>

              {/* Step 2: Job Description */}
              <div className={`w-full flex flex-col items-center gap-4 transition-all duration-500 ${resumes.length > 0 ? 'opacity-100 translate-y-0' : 'opacity-50 translate-y-4 pointer-events-none'}`}>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-gray-500 dark:text-gray-400">arrow_downward</span>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Next Step: Add Job Description</p>
                </div>

                <div className="w-full max-w-xl bg-gray-100 dark:bg-surface-dark rounded-lg p-4 transition-all border border-transparent focus-within:border-primary focus-within:ring-1 focus-within:ring-primary">

                  {/* Input Type Toggle */}
                  <div className="flex p-1 bg-gray-200 dark:bg-background-dark rounded-lg mb-4">
                    <button
                      onClick={() => setJdInputType('text')}
                      className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-bold rounded-md transition-all ${jdInputType === 'text' ? 'bg-white dark:bg-surface-dark shadow-sm text-primary' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
                    >
                      <span className="material-symbols-outlined text-base">edit_note</span>
                      Paste Text
                    </button>
                    <button
                      onClick={() => setJdInputType('file')}
                      className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-bold rounded-md transition-all ${jdInputType === 'file' ? 'bg-white dark:bg-surface-dark shadow-sm text-primary' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
                    >
                      <span className="material-symbols-outlined text-base">attach_file</span>
                      Upload File
                    </button>
                  </div>

                  {/* Text Input */}
                  {jdInputType === 'text' && (
                    <textarea
                      ref={jdInputRef}
                      className="w-full bg-transparent border-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:ring-0 resize-none h-24 p-2 text-sm"
                      placeholder="Paste your Job Description here..."
                      onChange={(e) => {
                        if (e.target.value.length > 10) {
                          setJobDescription(e.target.value);
                          setAppState(AppState.READY_TO_RANK);
                        } else {
                          setJobDescription('');
                          setAppState(AppState.RESUMES_UPLOADED);
                        }
                      }}
                    />
                  )}

                  {/* File Input */}
                  {jdInputType === 'file' && (
                    <div
                      onClick={() => jdFileInputRef.current?.click()}
                      className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-background-dark/50 transition-colors"
                    >
                      <input
                        type="file"
                        ref={jdFileInputRef}
                        className="hidden"
                        accept=".pdf,.docx,.txt"
                        onChange={handleJdFileChange}
                      />
                      {jdFile ? (
                        <div className="flex items-center gap-3 text-primary">
                          <span className="material-symbols-outlined text-3xl">description</span>
                          <div className="text-left">
                            <p className="font-bold text-sm line-clamp-1 break-all">{jdFile.name}</p>
                            <p className="text-xs text-gray-500">{(jdFile.size / 1024).toFixed(1)} KB</p>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setJdFile(null);
                              setAppState(AppState.RESUMES_UPLOADED);
                              if (jdFileInputRef.current) jdFileInputRef.current.value = '';
                            }}
                            className="ml-2 p-1 hover:bg-red-100 rounded-full text-red-500"
                          >
                            <span className="material-symbols-outlined text-lg">close</span>
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-gray-400 text-3xl mb-2">cloud_upload</span>
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-300">Click to upload JD</p>
                          <p className="text-xs text-gray-400 mt-1">PDF, DOCX, or TXT</p>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* Step 3: Action */}
                <div className={`transition-all duration-300 ${(jdInputType === 'text' && jobDescription) || (jdInputType === 'file' && jdFile)
                  ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'
                  }`}>
                  <button
                    onClick={handleRank}
                    className="flex min-w-[200px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-6 bg-primary hover:bg-blue-600 text-white text-base font-bold leading-normal tracking-[0.015em] shadow-lg shadow-primary/25 transition-all active:scale-95"
                  >
                    <span className="truncate">Generate Ranking Report</span>
                    <span className="material-symbols-outlined ml-2">auto_awesome</span>
                  </button>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );

  const renderFeatures = () => (
    <section id="about" className="py-16 sm:py-20 bg-gray-100 dark:bg-[#111a22] rounded-xl mx-4 sm:mx-8 lg:mx-20 mb-10">
      <div className="flex flex-col gap-10 px-4 py-10 @container">
        <div className="flex flex-col gap-4 text-center items-center">
          <h2 className="text-gray-900 dark:text-white tracking-light text-[32px] font-bold leading-tight @[480px]:text-4xl max-w-[720px]">
            Unlock a Faster, More Accurate Hiring Process
          </h2>
          <p className="text-gray-600 dark:text-text-secondary-dark text-base font-normal leading-normal max-w-[720px]">
            Our AI-driven platform analyzes resumes against your job description to identify the most qualified candidates, saving you time and effort.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 max-w-6xl mx-auto w-full">
          {[
            { icon: 'auto_awesome', title: 'AI-Powered Ranking', desc: 'Leverage advanced algorithms to score and rank candidates based on skills and experience.' },
            { icon: 'schedule', title: 'Save Time', desc: 'Drastically reduce manual screening time and focus on interviewing the best applicants.' },
            { icon: 'group', title: 'Find Top Talent', desc: 'Quickly identify high-potential candidates who are the best fit for the role.' }
          ].map((feature, idx) => (
            <div key={idx} className="flex gap-4 rounded-xl border border-gray-200 dark:border-border-dark bg-white dark:bg-surface-dark p-6 flex-col hover:border-primary/50 transition-colors">
              <div className="text-primary w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="material-symbols-outlined">{feature.icon}</span>
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-gray-900 dark:text-white text-lg font-bold leading-tight">{feature.title}</h3>
                <p className="text-gray-600 dark:text-text-secondary-dark text-sm leading-relaxed">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  const renderHowItWorks = () => (
    <section id="how-it-works" className="py-16 sm:py-20 border-t border-gray-200 dark:border-border-dark">
      <div className="flex flex-col items-center text-center">
        <h2 className="text-gray-900 dark:text-white text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-10">
          How It Works
        </h2>
        <div className="grid grid-cols-[40px_1fr] gap-x-4 px-4 w-full max-w-sm">
          {/* Step 1 */}
          <div className="flex flex-col items-center gap-1 pt-1">
            <div className="text-primary">
              <span className="material-symbols-outlined">upload_file</span>
            </div>
            <div className="w-[1.5px] bg-gray-200 dark:bg-border-dark h-full grow min-h-[40px]"></div>
          </div>
          <div className="flex flex-1 flex-col pb-8 text-left">
            <p className="text-gray-900 dark:text-white text-base font-medium leading-normal">1. Add Candidate Resumes</p>
            <p className="text-gray-600 dark:text-text-secondary-dark text-sm font-normal leading-normal">Upload multiple resumes or use your existing database.</p>
          </div>

          {/* Step 2 */}
          <div className="flex flex-col items-center gap-1">
            <div className="w-[1.5px] bg-gray-200 dark:bg-border-dark h-2"></div>
            <div className="text-primary">
              <span className="material-symbols-outlined">description</span>
            </div>
            <div className="w-[1.5px] bg-gray-200 dark:bg-border-dark h-full grow min-h-[40px]"></div>
          </div>
          <div className="flex flex-1 flex-col pb-8 text-left">
            <p className="text-gray-900 dark:text-white text-base font-medium leading-normal">2. Upload Job Description</p>
            <p className="text-gray-600 dark:text-text-secondary-dark text-sm font-normal leading-normal">Provide the role requirements and responsibilities.</p>
          </div>

          {/* Step 3 */}
          <div className="flex flex-col items-center gap-1 pb-1">
            <div className="w-[1.5px] bg-gray-200 dark:bg-border-dark h-2"></div>
            <div className="text-primary">
              <span className="material-symbols-outlined">leaderboard</span>
            </div>
          </div>
          <div className="flex flex-1 flex-col pt-1 text-left">
            <p className="text-gray-900 dark:text-white text-base font-medium leading-normal">3. Get Ranked Report</p>
            <p className="text-gray-600 dark:text-text-secondary-dark text-sm font-normal leading-normal">Receive an instant, data-driven report ranking all candidates.</p>
          </div>
        </div>
      </div>
    </section>
  );

  const renderLoading = () => (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 animate-fade-in">
      <div className="relative w-24 h-24">
        <div className="absolute inset-0 rounded-full border-4 border-gray-200 dark:border-gray-700"></div>
        <div className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="material-symbols-outlined text-primary text-3xl animate-pulse">psychology</span>
        </div>
      </div>
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Analyzing Candidates</h2>
        <p className="text-gray-500 dark:text-text-secondary-dark">Comparing {totalResumesCount} resumes against your job description...</p>
      </div>
    </div>
  );

  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden bg-background-light dark:bg-background-dark">
      <div className="layout-container flex h-full grow flex-col">
        <Header />

        <main className="flex-1 flex flex-col">
          {errorMsg && (
            <div className="bg-red-500/10 border border-red-500 text-red-500 p-4 mx-4 sm:mx-8 lg:mx-20 mt-6 rounded-lg flex items-center gap-3">
              <span className="material-symbols-outlined">error</span>
              <span>{errorMsg}</span>
              <button onClick={() => setAppState(AppState.READY_TO_RANK)} className="ml-auto hover:underline">Try Again</button>
            </div>
          )}

          {appState === AppState.RESULTS ? (
            <ResultsSection candidates={rankedCandidates} reportContent={reportContent} onReset={resetApp} />
          ) : appState === AppState.ANALYZING ? (
            renderLoading()
          ) : (
            <>
              {renderHero()}
              {renderFeatures()}
              {renderHowItWorks()}
              <PricingSection />
            </>
          )}
        </main>

        <Footer />
      </div>
    </div>
  );
};

export default App;