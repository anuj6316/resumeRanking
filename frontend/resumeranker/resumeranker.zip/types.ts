export interface Candidate {
  id: string;
  name: string;
  content: string; // The raw text content of the resume
}

export interface RankedCandidate {
  name: string;
  score: number;
  summary: string;
  pros: string[];
  cons: string[];
  fileName: string;
}

export interface RankingResult {
  candidates: RankedCandidate[];
}

export enum AppState {
  IDLE = 'IDLE',
  RESUMES_UPLOADED = 'RESUMES_UPLOADED',
  READY_TO_RANK = 'READY_TO_RANK',
  ANALYZING = 'ANALYZING',
  RESULTS = 'RESULTS',
  ERROR = 'ERROR'
}
