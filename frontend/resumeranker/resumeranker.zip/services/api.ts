import { RankedCandidate } from '../types';

const API_BASE_URL = 'http://localhost:8000';

export interface ReportResponse {
    results: string;
    report_path: string;
}

export const getTotalResumes = async (): Promise<number> => {
    const response = await fetch(`${API_BASE_URL}/total-resumes/`);
    if (!response.ok) {
        throw new Error('Failed to get total resumes');
    }
    const data = await response.json();
    return data.total;
};

export const uploadResumes = async (files: File[]): Promise<any> => {
    const formData = new FormData();
    files.forEach((file) => {
        formData.append('files', file);
    });

    const response = await fetch(`${API_BASE_URL}/upload-cv/`, {
        method: 'POST',
        body: formData,
    });

    if (!response.ok) {
        throw new Error('Failed to upload resumes');
    }

    return response.json();
};

export const getScores = async (jdFile: File | null, jdText: string | null, n: number = 5): Promise<Record<string, any>> => {
    const formData = new FormData();

    if (jdFile) {
        formData.append('file', jdFile);
    } else if (jdText) {
        // If we have text but no file, we need to create a file from text because /scores/ expects a file
        const blob = new Blob([jdText], { type: 'text/plain' });
        formData.append('file', blob, 'job_description.txt');
    } else {
        throw new Error("No JD provided");
    }

    const response = await fetch(`${API_BASE_URL}/scores/?n=${n}`, {
        method: 'POST',
        body: formData,
    });

    if (!response.ok) {
        throw new Error('Failed to get scores');
    }

    return response.json();
};

export const generateReport = async (jdFile: File | null, jdText: string | null, n: number = 5): Promise<ReportResponse> => {
    const formData = new FormData();

    // The /report/ endpoint accepts an optional file. 
    // If we have a file, send it.
    // If we have text, we can't easily send it as 'file' unless we blob it, 
    // BUT /report/ logic in backend says: "If no file provided, it uses the previously processed JD."
    // So if we called getScores first (which we usually do), the state is set.
    // However, to be safe and stateless, if we have a file, we send it.

    if (jdFile) {
        formData.append('file', jdFile);
    } else if (jdText) {
        // If we have text, we should probably send it as a file to ensure it's used
        const blob = new Blob([jdText], { type: 'text/plain' });
        formData.append('file', blob, 'job_description.txt');
    }

    const response = await fetch(`${API_BASE_URL}/report/?n=${n}`, {
        method: 'POST',
        body: formData,
    });

    if (!response.ok) {
        throw new Error('Failed to generate report');
    }

    return response.json();
};
