import * as React from 'react';
import { RankedCandidate } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import ReactMarkdown from 'react-markdown';

interface ResultsSectionProps {
  candidates: RankedCandidate[];
  reportContent: string;
  onReset: () => void;
}

const ResultsSection: React.FC<ResultsSectionProps> = ({ candidates, reportContent, onReset }) => {
  const chartData = candidates.map(c => ({
    name: c.name.split(' ')[0], // First name for chart
    fullName: c.name,
    score: c.score
  }));

  const chartHeight = Math.max(candidates.length * 60, 300);

  const CustomYAxisTick = (props: any) => {
    const { x, y, payload } = props;
    const candidate = candidates.find(c => c.name.startsWith(payload.value) || c.name === payload.value);
    const fileName = candidate ? candidate.fileName : "";

    return (
      <g transform={`translate(${x},${y})`}>
        <text
          x={0}
          y={0}
          dy={4}
          textAnchor="end"
          fill="#666"
          className="text-xs font-medium hover:text-primary cursor-pointer hover:underline"
          onClick={() => {
            if (fileName) {
              window.open(`http://localhost:8000/view-resume/${fileName}`, '_blank');
            }
          }}
        >
          {payload.value.length > 15 ? `${payload.value.substring(0, 15)}...` : payload.value}
        </text>
      </g>
    );
  };

  return (
    <section className="py-10 animate-fade-in w-full max-w-6xl mx-auto px-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Ranking Report</h2>
          <p className="text-gray-500 dark:text-text-secondary-dark">Based on your job description and uploaded resumes</p>
        </div>
        <button
          onClick={onReset}
          className="px-6 py-2.5 bg-gray-200 dark:bg-border-dark hover:dark:bg-gray-700 text-gray-900 dark:text-white rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          <span className="material-symbols-outlined text-sm">restart_alt</span>
          Start Over
        </button>
      </div>

      {/* Chart Section */}
      <div className="bg-white dark:bg-surface-dark rounded-xl border border-gray-200 dark:border-border-dark p-6 mb-8 shadow-sm overflow-hidden">
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Candidate Scores Overview</h3>
        <div style={{ height: `${chartHeight}px`, width: '100%' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 100, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} hide />
              <YAxis
                type="category"
                dataKey="fullName"
                width={100}
                tick={<CustomYAxisTick />}
                interval={0}
              />
              <Tooltip
                cursor={{ fill: 'transparent' }}
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#fff' }}
              />
              <Bar dataKey="score" radius={[0, 4, 4, 0]} barSize={32}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.score > 80 ? '#137fec' : entry.score > 60 ? '#6366f1' : '#94a3b8'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Report Section */}
      <div className="bg-white dark:bg-surface-dark rounded-xl border border-gray-200 dark:border-border-dark p-8 shadow-sm mb-8">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
          <span className="material-symbols-outlined text-primary">description</span>
          Detailed Analysis
        </h3>
        <div className="prose dark:prose-invert max-w-none">
          <ReactMarkdown>{reportContent}</ReactMarkdown>
        </div>
      </div>

    </section>
  );
};

export default ResultsSection;